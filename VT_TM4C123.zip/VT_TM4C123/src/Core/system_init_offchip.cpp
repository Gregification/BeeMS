/*
 * system_init_offchip.cpp
 *
 *  Created on: May 13, 2025
 *      Author: turtl
 */

#include "Core/system.hpp"

#include <driverlib/gpio.h>
#include <driverlib/rom_map.h>
#include <driverlib/sysctl.h>
#include <FreeRTOS.h>

void system_init_offchip()
{
    // TODO
}
